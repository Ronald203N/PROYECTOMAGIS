USE MagisAuto;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/*
  Registro de varios vehículos en una sola operación.

  @Vehiculos es un arreglo JSON, por ejemplo:
  [
    {"VIN":"MM8TF83J0VRH65433","MarcaId":5,"Linea":"BT-50 Doble Cabina 4x4","Anio":2027,
     "Color":"Blanco perlado","ValorAgencia":345000,"Placa":""},
    {"VIN":"...", ...}
  ]

  Todo o nada: si una fila tiene un error, no se guarda ninguna y el
  mensaje indica el número de fila.
*/
CREATE OR ALTER PROCEDURE dbo.sp_Vehiculo_InsertarLote
    @Vehiculos NVARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Msg NVARCHAR(400), @Fila INT, @Dato NVARCHAR(100);

    IF @Vehiculos IS NULL OR ISJSON(@Vehiculos) = 0
        THROW 50001, 'La lista de vehículos no tiene un formato válido.', 1;

    DECLARE @Lote TABLE (
        Fila          INT            NOT NULL PRIMARY KEY,
        VIN           NVARCHAR(40)   NULL,
        MarcaTexto    NVARCHAR(40)   NULL,
        MarcaId       INT            NULL,
        Linea         NVARCHAR(100)  NULL,
        AnioTexto     NVARCHAR(20)   NULL,
        Anio          SMALLINT       NULL,
        Color         NVARCHAR(60)   NULL,
        ValorTexto    NVARCHAR(40)   NULL,
        ValorAgencia  DECIMAL(12,2)  NULL,
        Placa         NVARCHAR(20)   NULL
    );

    INSERT INTO @Lote (Fila, VIN, MarcaTexto, Linea, AnioTexto, Color, ValorTexto, Placa)
    SELECT CAST(j.[key] AS INT) + 1,
           UPPER(LTRIM(RTRIM(JSON_VALUE(j.value, '$.VIN')))),
           LTRIM(RTRIM(JSON_VALUE(j.value, '$.MarcaId'))),
           LTRIM(RTRIM(JSON_VALUE(j.value, '$.Linea'))),
           LTRIM(RTRIM(JSON_VALUE(j.value, '$.Anio'))),
           NULLIF(LTRIM(RTRIM(JSON_VALUE(j.value, '$.Color'))), ''),
           LTRIM(RTRIM(JSON_VALUE(j.value, '$.ValorAgencia'))),
           NULLIF(UPPER(LTRIM(RTRIM(JSON_VALUE(j.value, '$.Placa')))), '')
    FROM OPENJSON(@Vehiculos) j;

    UPDATE @Lote
       SET MarcaId      = TRY_CAST(MarcaTexto AS INT),
           Anio         = TRY_CAST(AnioTexto AS SMALLINT),
           ValorAgencia = TRY_CAST(ValorTexto AS DECIMAL(12,2));

    IF NOT EXISTS (SELECT 1 FROM @Lote)
        THROW 50001, 'Agregue al menos un vehículo.', 1;
    IF (SELECT COUNT(*) FROM @Lote) > 200
        THROW 50001, 'Se pueden registrar hasta 200 vehículos por operación.', 1;

    -- 1. VIN con formato correcto (17 caracteres, sin I, O ni Q)
    SELECT TOP (1) @Fila = Fila, @Dato = ISNULL(VIN, '')
    FROM @Lote
    WHERE VIN IS NULL OR LEN(VIN) <> 17 OR VIN LIKE '%[^A-Z0-9]%' OR VIN LIKE '%[IOQ]%'
    ORDER BY Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': el VIN "', @Dato, '" debe tener 17 letras o números y no puede llevar I, O ni Q.');
        THROW 50001, @Msg, 1;
    END

    -- 2. VIN repetido dentro de la misma lista
    SELECT TOP (1) @Fila = b.Fila, @Dato = b.VIN
    FROM @Lote a JOIN @Lote b ON b.VIN = a.VIN AND b.Fila > a.Fila
    ORDER BY b.Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': el VIN ', @Dato, ' está repetido en la lista.');
        THROW 50001, @Msg, 1;
    END

    -- 3. VIN ya registrado
    SELECT TOP (1) @Fila = l.Fila, @Dato = l.VIN
    FROM @Lote l JOIN dbo.Vehiculo v ON v.VIN = l.VIN
    ORDER BY l.Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': ya existe un vehículo registrado con el VIN ', @Dato, '.');
        THROW 50001, @Msg, 1;
    END

    -- 4. Marca existente
    SELECT TOP (1) @Fila = l.Fila
    FROM @Lote l LEFT JOIN dbo.Marca m ON m.MarcaId = l.MarcaId
    WHERE m.MarcaId IS NULL
    ORDER BY l.Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': seleccione una marca válida.');
        THROW 50001, @Msg, 1;
    END

    -- 5. Línea obligatoria
    SELECT TOP (1) @Fila = Fila FROM @Lote
    WHERE Linea IS NULL OR Linea = '' OR LEN(Linea) > 60
    ORDER BY Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': escriba la línea o modelo (máximo 60 caracteres).');
        THROW 50001, @Msg, 1;
    END

    -- 6. Año válido
    SELECT TOP (1) @Fila = Fila FROM @Lote
    WHERE Anio IS NULL OR Anio NOT BETWEEN 1990 AND 2100
    ORDER BY Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': el año debe estar entre 1990 y 2100.');
        THROW 50001, @Msg, 1;
    END

    -- 7. Valor de agencia mayor a cero
    SELECT TOP (1) @Fila = Fila FROM @Lote
    WHERE ValorAgencia IS NULL OR ValorAgencia <= 0
    ORDER BY Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': el valor de agencia debe ser un número mayor a cero.');
        THROW 50001, @Msg, 1;
    END

    -- 8. Color y placa dentro del tamaño permitido
    SELECT TOP (1) @Fila = Fila FROM @Lote
    WHERE LEN(Color) > 30 OR LEN(Placa) > 10
    ORDER BY Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': el color admite 30 caracteres y la placa 10.');
        THROW 50001, @Msg, 1;
    END

    -- 9. Placa repetida en la lista o ya registrada
    SELECT TOP (1) @Fila = b.Fila, @Dato = b.Placa
    FROM @Lote a JOIN @Lote b ON b.Placa = a.Placa AND b.Fila > a.Fila
    ORDER BY b.Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': la placa ', @Dato, ' está repetida en la lista.');
        THROW 50001, @Msg, 1;
    END

    SELECT TOP (1) @Fila = l.Fila, @Dato = l.Placa
    FROM @Lote l JOIN dbo.Vehiculo v ON v.Placa = l.Placa
    ORDER BY l.Fila;
    IF @Fila IS NOT NULL
    BEGIN
        SET @Msg = CONCAT('Fila ', @Fila, ': ya existe un vehículo registrado con la placa ', @Dato, '.');
        THROW 50001, @Msg, 1;
    END

    BEGIN TRANSACTION;
        INSERT INTO dbo.Vehiculo (VIN, MarcaId, Linea, Anio, Color, ValorAgencia, Placa)
        SELECT VIN, MarcaId, Linea, Anio, Color, ValorAgencia, Placa
        FROM @Lote;

        INSERT INTO dbo.HistorialValorVehiculo (VIN, Fecha, ValorEstimado, PorcentajeDepreciacion, Concepto)
        SELECT VIN, CAST(SYSDATETIME() AS DATE), ValorAgencia, 0, 'Valor de agencia (precio de contado)'
        FROM @Lote;
    COMMIT TRANSACTION;

    SELECT v.*
    FROM dbo.vw_Vehiculo v
    JOIN @Lote l ON l.VIN = v.VIN
    ORDER BY l.Fila;
END
GO

PRINT 'Procedimiento sp_Vehiculo_InsertarLote creado correctamente.';
GO
