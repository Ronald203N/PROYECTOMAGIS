USE MagisAuto;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/*
  Catálogo de departamentos y municipios de Guatemala (22 departamentos, 340 municipios).
  Lo usa la pantalla para elegir primero el departamento y luego un municipio de ese departamento.
  Las direcciones siguen guardando el nombre del municipio y del departamento como texto,
  así que los datos existentes y los reportes no cambian.
  Se puede ejecutar sobre una base que ya tiene datos, y más de una vez.
*/

IF OBJECT_ID('dbo.Departamento', 'U') IS NULL
    CREATE TABLE dbo.Departamento (
        DepartamentoId  TINYINT      NOT NULL CONSTRAINT PK_Departamento PRIMARY KEY,
        Nombre          VARCHAR(40)  NOT NULL CONSTRAINT UQ_Departamento_Nombre UNIQUE
    );
GO

IF OBJECT_ID('dbo.Municipio', 'U') IS NULL
    CREATE TABLE dbo.Municipio (
        MunicipioId     SMALLINT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Municipio PRIMARY KEY,
        DepartamentoId  TINYINT      NOT NULL,
        Nombre          VARCHAR(60)  NOT NULL,
        CONSTRAINT FK_Municipio_Departamento FOREIGN KEY (DepartamentoId) REFERENCES dbo.Departamento(DepartamentoId),
        CONSTRAINT UQ_Municipio_Departamento_Nombre UNIQUE (DepartamentoId, Nombre)
    );
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Departamento)
BEGIN
    INSERT INTO dbo.Departamento (DepartamentoId, Nombre) VALUES
    (1, 'Alta Verapaz'),
    (2, 'Baja Verapaz'),
    (3, 'Chimaltenango'),
    (4, 'Chiquimula'),
    (5, 'El Progreso'),
    (6, 'Escuintla'),
    (7, 'Guatemala'),
    (8, 'Huehuetenango'),
    (9, 'Izabal'),
    (10, 'Jalapa'),
    (11, 'Jutiapa'),
    (12, 'Petén'),
    (13, 'Quetzaltenango'),
    (14, 'Quiché'),
    (15, 'Retalhuleu'),
    (16, 'Sacatepéquez'),
    (17, 'San Marcos'),
    (18, 'Santa Rosa'),
    (19, 'Sololá'),
    (20, 'Suchitepéquez'),
    (21, 'Totonicapán'),
    (22, 'Zacapa');
END
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Municipio)
BEGIN
    INSERT INTO dbo.Municipio (DepartamentoId, Nombre) VALUES
    -- Alta Verapaz (17)
    (1, 'Cahabón'),
    (1, 'Chahal'),
    (1, 'Chisec'),
    (1, 'Cobán'),
    (1, 'Fray Bartolomé de las Casas'),
    (1, 'Lanquín'),
    (1, 'Panzós'),
    (1, 'Raxruhá'),
    (1, 'San Cristóbal Verapaz'),
    (1, 'San Juan Chamelco'),
    (1, 'San Pedro Carchá'),
    (1, 'Santa Catalina la Tinta'),
    (1, 'Santa Cruz Verapaz'),
    (1, 'Senahú'),
    (1, 'Tactic'),
    (1, 'Tamahú'),
    (1, 'Tucurú'),
    -- Baja Verapaz (8)
    (2, 'Cubulco'),
    (2, 'Granados'),
    (2, 'Purulhá'),
    (2, 'Rabinal'),
    (2, 'Salamá'),
    (2, 'San Jerónimo'),
    (2, 'San Miguel Chicaj'),
    (2, 'Santa Cruz el Chol'),
    -- Chimaltenango (16)
    (3, 'Acatenango'),
    (3, 'Chimaltenango'),
    (3, 'El Tejar'),
    (3, 'Parramos'),
    (3, 'Patzicía'),
    (3, 'Patzún'),
    (3, 'Pochuta'),
    (3, 'San Andrés Itzapa'),
    (3, 'San José Poaquíl'),
    (3, 'San Juan Comalapa'),
    (3, 'San Martín Jilotepeque'),
    (3, 'San Pedro Yepocapa'),
    (3, 'Santa Apolonia'),
    (3, 'Santa Cruz Balanyá'),
    (3, 'Tecpán Guatemala'),
    (3, 'Zaragoza'),
    -- Chiquimula (11)
    (4, 'Camotán'),
    (4, 'Chiquimula'),
    (4, 'Concepción Las Minas'),
    (4, 'Esquipulas'),
    (4, 'Ipala'),
    (4, 'Jocotán'),
    (4, 'Olopa'),
    (4, 'Quetzaltepeque'),
    (4, 'San Jacinto'),
    (4, 'San José la Arada'),
    (4, 'San Juan Ermita'),
    -- El Progreso (8)
    (5, 'El Jícaro'),
    (5, 'Guastatoya'),
    (5, 'Morazán'),
    (5, 'San Agustín Acasaguastlán'),
    (5, 'San Antonio La Paz'),
    (5, 'San Cristóbal Acasaguastlán'),
    (5, 'Sanarate'),
    (5, 'Sansare'),
    -- Escuintla (14)
    (6, 'Escuintla'),
    (6, 'Guanagazapa'),
    (6, 'Iztapa'),
    (6, 'La Democracia'),
    (6, 'La Gomera'),
    (6, 'Masagua'),
    (6, 'Nueva Concepción'),
    (6, 'Palín'),
    (6, 'San José'),
    (6, 'San Vicente Pacaya'),
    (6, 'Santa Lucía Cotzumalguapa'),
    (6, 'Sipacate'),
    (6, 'Siquinalá'),
    (6, 'Tiquisate'),
    -- Guatemala (17)
    (7, 'Amatitlán'),
    (7, 'Chinautla'),
    (7, 'Chuarrancho'),
    (7, 'Fraijanes'),
    (7, 'Guatemala'),
    (7, 'Mixco'),
    (7, 'Palencia'),
    (7, 'San José del Golfo'),
    (7, 'San José Pinula'),
    (7, 'San Juan Sacatepéquez'),
    (7, 'San Miguel Petapa'),
    (7, 'San Pedro Ayampuc'),
    (7, 'San Pedro Sacatepéquez'),
    (7, 'San Raymundo'),
    (7, 'Santa Catarina Pinula'),
    (7, 'Villa Canales'),
    (7, 'Villa Nueva'),
    -- Huehuetenango (33)
    (8, 'Aguacatán'),
    (8, 'Chiantla'),
    (8, 'Colotenango'),
    (8, 'Concepción Huista'),
    (8, 'Cuilco'),
    (8, 'Huehuetenango'),
    (8, 'Jacaltenango'),
    (8, 'La Democracia'),
    (8, 'La Libertad'),
    (8, 'Malacatancito'),
    (8, 'Nentón'),
    (8, 'Petatán'),
    (8, 'San Antonio Huista'),
    (8, 'San Gaspar Ixchil'),
    (8, 'San Ildefonso Ixtahuacán'),
    (8, 'San Juan Atitán'),
    (8, 'San Juan Ixcoy'),
    (8, 'San Mateo Ixtatán'),
    (8, 'San Miguel Acatán'),
    (8, 'San Pedro Nécta'),
    (8, 'San Pedro Soloma'),
    (8, 'San Rafael La Independencia'),
    (8, 'San Rafael Pétzal'),
    (8, 'San Sebastián Coatán'),
    (8, 'San Sebastián Huehuetenango'),
    (8, 'Santa Ana Huista'),
    (8, 'Santa Bárbara'),
    (8, 'Santa Cruz Barillas'),
    (8, 'Santa Eulalia'),
    (8, 'Santiago Chimaltenango'),
    (8, 'Tectitán'),
    (8, 'Todos Santos Cuchumatán'),
    (8, 'Unión Cantinil'),
    -- Izabal (5)
    (9, 'El Estor'),
    (9, 'Livingston'),
    (9, 'Los Amates'),
    (9, 'Morales'),
    (9, 'Puerto Barrios'),
    -- Jalapa (7)
    (10, 'Jalapa'),
    (10, 'Mataquescuintla'),
    (10, 'Monjas'),
    (10, 'San Carlos Alzatate'),
    (10, 'San Luis Jilotepeque'),
    (10, 'San Manuel Chaparrón'),
    (10, 'San Pedro Pinula'),
    -- Jutiapa (17)
    (11, 'Agua Blanca'),
    (11, 'Asunción Mita'),
    (11, 'Atescatempa'),
    (11, 'Comapa'),
    (11, 'Conguaco'),
    (11, 'El Adelanto'),
    (11, 'El Progreso'),
    (11, 'Jalpatagua'),
    (11, 'Jerez'),
    (11, 'Jutiapa'),
    (11, 'Moyuta'),
    (11, 'Pasaco'),
    (11, 'Quesada'),
    (11, 'San José Acatempa'),
    (11, 'Santa Catarina Mita'),
    (11, 'Yupiltepeque'),
    (11, 'Zapotitlán'),
    -- Petén (14)
    (12, 'Dolores'),
    (12, 'El Chal'),
    (12, 'Flores'),
    (12, 'La Libertad'),
    (12, 'Las Cruces'),
    (12, 'Melchor de Mencos'),
    (12, 'Poptún'),
    (12, 'San Andrés'),
    (12, 'San Benito'),
    (12, 'San Francisco'),
    (12, 'San José'),
    (12, 'San Luis'),
    (12, 'Santa Ana'),
    (12, 'Sayaxché'),
    -- Quetzaltenango (24)
    (13, 'Almolonga'),
    (13, 'Cabricán'),
    (13, 'Cajolá'),
    (13, 'Cantel'),
    (13, 'Coatepeque'),
    (13, 'Colomba Costa Cuca'),
    (13, 'Concepción Chiquirichapa'),
    (13, 'El Palmar'),
    (13, 'Flores Costa Cuca'),
    (13, 'Génova'),
    (13, 'Huitán'),
    (13, 'La Esperanza'),
    (13, 'Olintepeque'),
    (13, 'Palestina de Los Altos'),
    (13, 'Quetzaltenango'),
    (13, 'Salcajá'),
    (13, 'San Carlos Sija'),
    (13, 'San Francisco La Unión'),
    (13, 'San Juan Ostuncalco'),
    (13, 'San Martín Sacatepéquez'),
    (13, 'San Mateo'),
    (13, 'San Miguel Sigüilá'),
    (13, 'Sibilia'),
    (13, 'Zunil'),
    -- Quiché (21)
    (14, 'Canillá'),
    (14, 'Chajul'),
    (14, 'Chicamán'),
    (14, 'Chiché'),
    (14, 'Chinique'),
    (14, 'Cunén'),
    (14, 'Ixcán'),
    (14, 'Joyabaj'),
    (14, 'Nebaj'),
    (14, 'Pachalum'),
    (14, 'Patzité'),
    (14, 'Sacapulas'),
    (14, 'San Andrés Sajcabajá'),
    (14, 'San Antonio Ilotenango'),
    (14, 'San Bartolomé Jocotenango'),
    (14, 'San Juan Cotzal'),
    (14, 'San Pedro Jocopilas'),
    (14, 'Santa Cruz del Quiché'),
    (14, 'Santo Tomás Chichicastenango'),
    (14, 'Uspantán'),
    (14, 'Zacualpa'),
    -- Retalhuleu (9)
    (15, 'Champerico'),
    (15, 'El Asintal'),
    (15, 'Nuevo San Carlos'),
    (15, 'Retalhuleu'),
    (15, 'San Andrés Villa Seca'),
    (15, 'San Felipe'),
    (15, 'San Martín Zapotitlán'),
    (15, 'San Sebastián'),
    (15, 'Santa Cruz Muluá'),
    -- Sacatepéquez (16)
    (16, 'Alotenango'),
    (16, 'Antigua Guatemala'),
    (16, 'Ciudad Vieja'),
    (16, 'Jocotenango'),
    (16, 'Magdalena Milpas Altas'),
    (16, 'Pastores'),
    (16, 'San Antonio Aguas Calientes'),
    (16, 'San Bartolomé Milpas Altas'),
    (16, 'San Lucas Sacatepéquez'),
    (16, 'San Miguel Dueñas'),
    (16, 'Santa Catarina Barahona'),
    (16, 'Santa Lucía Milpas Altas'),
    (16, 'Santa María de Jesús'),
    (16, 'Santiago Sacatepéquez'),
    (16, 'Santo Domingo Xenacoj'),
    (16, 'Sumpango'),
    -- San Marcos (30)
    (17, 'Ayutla'),
    (17, 'Catarina'),
    (17, 'Comitancillo'),
    (17, 'Concepción Tutuapa'),
    (17, 'El Quetzal'),
    (17, 'El Tumbador'),
    (17, 'Esquipulas Palo Gordo'),
    (17, 'Ixchiguán'),
    (17, 'La Blanca'),
    (17, 'La Reforma'),
    (17, 'Malacatán'),
    (17, 'Nuevo Progreso'),
    (17, 'Ocós'),
    (17, 'Pajapita'),
    (17, 'Río Blanco'),
    (17, 'San Antonio Sacatepéquez'),
    (17, 'San Cristóbal Cucho'),
    (17, 'San José El Rodeo'),
    (17, 'San José Ojetenam'),
    (17, 'San Lorenzo'),
    (17, 'San Marcos'),
    (17, 'San Miguel Ixtahuacán'),
    (17, 'San Pablo'),
    (17, 'San Pedro Sacatepéquez'),
    (17, 'San Rafael Pie de la Cuesta'),
    (17, 'Sibinal'),
    (17, 'Sipacapa'),
    (17, 'Tacaná'),
    (17, 'Tajumulco'),
    (17, 'Tejutla'),
    -- Santa Rosa (14)
    (18, 'Barberena'),
    (18, 'Casillas'),
    (18, 'Chiquimulilla'),
    (18, 'Cuilapa'),
    (18, 'Guazacapán'),
    (18, 'Nueva Santa Rosa'),
    (18, 'Oratorio'),
    (18, 'Pueblo Nuevo Viñas'),
    (18, 'San Juan Tecuaco'),
    (18, 'San Rafael las Flores'),
    (18, 'Santa Cruz Naranjo'),
    (18, 'Santa María Ixhuatán'),
    (18, 'Santa Rosa de Lima'),
    (18, 'Taxisco'),
    -- Sololá (19)
    (19, 'Concepción'),
    (19, 'Nahualá'),
    (19, 'Panajachel'),
    (19, 'San Andrés Semetabaj'),
    (19, 'San Antonio Palopó'),
    (19, 'San José Chacayá'),
    (19, 'San Juan La Laguna'),
    (19, 'San Lucas Tolimán'),
    (19, 'San Marcos La Laguna'),
    (19, 'San Pablo La Laguna'),
    (19, 'San Pedro La Laguna'),
    (19, 'Santa Catarina Ixtahuacán'),
    (19, 'Santa Catarina Palopó'),
    (19, 'Santa Clara La Laguna'),
    (19, 'Santa Cruz La Laguna'),
    (19, 'Santa Lucía Utatlán'),
    (19, 'Santa María Visitación'),
    (19, 'Santiago Atitlán'),
    (19, 'Sololá'),
    -- Suchitepéquez (21)
    (20, 'Chicacao'),
    (20, 'Cuyotenango'),
    (20, 'Mazatenango'),
    (20, 'Patulul'),
    (20, 'Pueblo Nuevo'),
    (20, 'Río Bravo'),
    (20, 'Samayac'),
    (20, 'San Antonio Suchitepéquez'),
    (20, 'San Bernardino'),
    (20, 'San Francisco Zapotitlán'),
    (20, 'San Gabriel'),
    (20, 'San José El Ídolo'),
    (20, 'San José La Máquina'),
    (20, 'San Juan Bautista'),
    (20, 'San Lorenzo'),
    (20, 'San Miguel Panán'),
    (20, 'San Pablo Jocopilas'),
    (20, 'Santa Bárbara'),
    (20, 'Santo Domingo Suchitepéquez'),
    (20, 'Santo Tomás La Unión'),
    (20, 'Zunilito'),
    -- Totonicapán (8)
    (21, 'Momostenango'),
    (21, 'San Andrés Xecul'),
    (21, 'San Bartolo'),
    (21, 'San Cristóbal Totonicapán'),
    (21, 'San Francisco El Alto'),
    (21, 'Santa Lucía La Reforma'),
    (21, 'Santa María Chiquimula'),
    (21, 'Totonicapán'),
    -- Zacapa (11)
    (22, 'Cabañas'),
    (22, 'Estanzuela'),
    (22, 'Gualán'),
    (22, 'Huité'),
    (22, 'La Unión'),
    (22, 'Río Hondo'),
    (22, 'San Diego'),
    (22, 'San Jorge'),
    (22, 'Teculután'),
    (22, 'Usumatlán'),
    (22, 'Zacapa');
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_Departamento_Listar
AS
BEGIN
    SET NOCOUNT ON;
    SELECT DepartamentoId, Nombre,
           (SELECT COUNT(*) FROM dbo.Municipio m WHERE m.DepartamentoId = d.DepartamentoId) AS Municipios
    FROM dbo.Departamento d
    ORDER BY Nombre;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_Municipio_Listar
AS
BEGIN
    SET NOCOUNT ON;
    SELECT m.MunicipioId, m.Nombre AS Municipio, d.DepartamentoId, d.Nombre AS Departamento
    FROM dbo.Municipio m
    JOIN dbo.Departamento d ON d.DepartamentoId = m.DepartamentoId
    ORDER BY d.Nombre, m.Nombre;
END
GO

CREATE OR ALTER PROCEDURE dbo.sp_Municipio_Buscar
    @DepartamentoId  TINYINT     = NULL,
    @Departamento    VARCHAR(40) = NULL,
    @Nombre          VARCHAR(60) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SELECT m.MunicipioId, m.Nombre AS Municipio, d.DepartamentoId, d.Nombre AS Departamento
    FROM dbo.Municipio m
    JOIN dbo.Departamento d ON d.DepartamentoId = m.DepartamentoId
    WHERE (@DepartamentoId IS NULL OR d.DepartamentoId = @DepartamentoId)
      AND (@Departamento   IS NULL OR d.Nombre = @Departamento)
      AND (@Nombre         IS NULL OR m.Nombre LIKE '%' + @Nombre + '%')
    ORDER BY d.Nombre, m.Nombre;
END
GO

SELECT COUNT(*) AS Departamentos FROM dbo.Departamento;
SELECT COUNT(*) AS Municipios FROM dbo.Municipio;
PRINT 'Catálogo de departamentos y municipios instalado correctamente.';
GO
