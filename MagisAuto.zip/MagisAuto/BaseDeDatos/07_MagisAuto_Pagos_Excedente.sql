USE MagisAuto;
GO
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

/*
  Pagos mayores a la cuota.

  Cuando el cliente paga más que el saldo de la cuota, el excedente puede:
    'CUOTAS'  -> aplicarse a las siguientes cuotas, en orden (una transacción y un recibo por cuota).
    'CAPITAL' -> abonarse a capital: se cancela la cuota y el excedente reduce el saldo;
                 las cuotas que faltan se recalculan con el mismo plazo (bajan de valor).

  Este script se puede ejecutar sobre una base que ya tiene datos.
*/

-- 1. Tipo de pago en TransaccionPago ------------------------------------------------
IF COL_LENGTH('dbo.TransaccionPago', 'TipoPago') IS NULL
BEGIN
    ALTER TABLE dbo.TransaccionPago
        ADD TipoPago VARCHAR(10) NOT NULL
            CONSTRAINT DF_TransaccionPago_TipoPago DEFAULT 'CUOTA'
            CONSTRAINT CK_TransaccionPago_TipoPago CHECK (TipoPago IN ('CUOTA', 'CAPITAL'));
END
GO

-- 2. Vistas -------------------------------------------------------------------------
CREATE OR ALTER VIEW dbo.vw_TransaccionPago
AS
SELECT tp.TransaccionId, tp.NumeroRecibo, tp.FechaHora, tp.Monto,
       tp.TipoPago,
       CASE tp.TipoPago WHEN 'CAPITAL' THEN 'Abono a capital' ELSE 'Pago de cuota' END AS Concepto,
       tp.MedioPagoId, mp.Codigo AS CodigoMedioPago, mp.Descripcion AS MedioPago,
       tp.ReferenciaBancaria,
       q.CuotaId, q.NumeroCuota, q.FechaVencimiento,
       cr.CreditoId, cr.NumeroObligacion, cr.ClienteId,
       p.Nombres + ' ' + p.Apellidos AS Cliente,
       cr.VendedorId, ve.Nombres + ' ' + ve.Apellidos AS Vendedor,
       tp.PorcentajeComision, tp.ComisionVendedor, tp.Anulada
FROM dbo.TransaccionPago tp
JOIN dbo.MedioPago mp ON mp.MedioPagoId = tp.MedioPagoId
JOIN dbo.Cuota q      ON q.CuotaId      = tp.CuotaId
JOIN dbo.Credito cr   ON cr.CreditoId   = q.CreditoId
JOIN dbo.Cliente c    ON c.ClienteId    = cr.ClienteId
JOIN dbo.Persona p    ON p.PersonaId    = c.PersonaId
JOIN dbo.Vendedor ve  ON ve.VendedorId  = cr.VendedorId;
GO

-- TotalPagado ahora incluye los abonos a capital vigentes
CREATE OR ALTER VIEW dbo.vw_Credito
AS
SELECT cr.CreditoId, cr.NumeroObligacion,
       cr.ClienteId, p.DPI, p.NIT, p.Nombres + ' ' + p.Apellidos AS Cliente,
       cr.VIN, m.Nombre AS Marca, v.Linea, v.Anio, v.Placa,
       cr.VendedorId, ve.CodigoEmpleado, ve.Nombres + ' ' + ve.Apellidos AS Vendedor,
       a.Nombre AS Agencia, a.Region,
       cr.FechaAprobacion, cr.PlazoMeses, cr.PrecioContado, cr.Enganche, cr.MontoFinanciado,
       cr.TasaInteresAnual, cr.PorcentajeComision,
       cr.CuotaNivelada, cr.ManejoCuenta, cr.SeguroAuto, cr.SeguroVida,
       cr.CuotaNivelada + cr.ManejoCuenta + cr.SeguroAuto + cr.SeguroVida AS CuotaMensualTotal,
       cr.TotalIntereses, cr.TotalRecaudable,
       cr.PorcentajeDepreciacion,
       CAST(ROUND(cr.PrecioContado * (1 - cr.PorcentajeDepreciacion / 100), 2) AS DECIMAL(12,2)) AS ValorDespuesRodaje,
       ISNULL(r.CuotasPagadas, 0)    AS CuotasPagadas,
       ISNULL(r.CuotasVencidas, 0)   AS CuotasVencidas,
       ISNULL(r.TotalPagado, 0) + ISNULL(ab.AbonosCapital, 0) AS TotalPagado,
       ISNULL(ab.AbonosCapital, 0)   AS AbonosCapital,
       ISNULL(r.SaldoPendiente, 0)   AS SaldoPendiente,
       ISNULL(r.CapitalPendiente, 0) AS CapitalPendiente,
       ISNULL(r.DiasAtraso, 0)       AS DiasAtraso,
       (SELECT COUNT(*) FROM dbo.CreditoFiador cf WHERE cf.CreditoId = cr.CreditoId) AS Fiadores,
       cr.Estado, cr.FechaRegistro
FROM dbo.Credito cr
JOIN dbo.Cliente  c  ON c.ClienteId   = cr.ClienteId
JOIN dbo.Persona  p  ON p.PersonaId   = c.PersonaId
JOIN dbo.Vehiculo v  ON v.VIN         = cr.VIN
JOIN dbo.Marca    m  ON m.MarcaId     = v.MarcaId
JOIN dbo.Vendedor ve ON ve.VendedorId = cr.VendedorId
JOIN dbo.Agencia  a  ON a.AgenciaId   = ve.AgenciaId
OUTER APPLY (
    SELECT SUM(CASE WHEN q.Estado = 'PAGADA' THEN 1 ELSE 0 END) AS CuotasPagadas,
           SUM(CASE WHEN q.Estado <> 'PAGADA' AND q.FechaVencimiento < CAST(GETDATE() AS DATE) THEN 1 ELSE 0 END) AS CuotasVencidas,
           SUM(q.MontoPagado) AS TotalPagado,
           SUM(q.TotalCuota - q.MontoPagado) AS SaldoPendiente,
           SUM(CASE WHEN q.Estado <> 'PAGADA' THEN q.Capital ELSE 0 END) AS CapitalPendiente,
           MAX(CASE WHEN q.Estado <> 'PAGADA' AND q.FechaVencimiento < CAST(GETDATE() AS DATE)
                    THEN DATEDIFF(DAY, q.FechaVencimiento, CAST(GETDATE() AS DATE)) ELSE 0 END) AS DiasAtraso
    FROM dbo.Cuota q
    WHERE q.CreditoId = cr.CreditoId
) r
OUTER APPLY (
    SELECT SUM(tp.Monto) AS AbonosCapital
    FROM dbo.TransaccionPago tp
    JOIN dbo.Cuota q ON q.CuotaId = tp.CuotaId
    WHERE q.CreditoId = cr.CreditoId AND tp.TipoPago = 'CAPITAL' AND tp.Anulada = 0
) ab;
GO

-- 3. Recalcular las cuotas que faltan -----------------------------------------------
/*
  Saldo de capital = monto financiado
                   - capital de las cuotas hasta la última que tiene pagos
                   - abonos a capital vigentes.
  Ese saldo se vuelve a amortizar en las cuotas restantes (sin pagos), con el mismo
  plazo y la misma tasa, usando la fórmula de cuota nivelada.
*/
CREATE OR ALTER PROCEDURE dbo.sp_Credito_RecalcularPendientes
    @CreditoId INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Monto DECIMAL(12,2), @Tasa DECIMAL(5,2);
    SELECT @Monto = MontoFinanciado, @Tasa = TasaInteresAnual FROM dbo.Credito WHERE CreditoId = @CreditoId;
    IF @Monto IS NULL
        THROW 50001, 'El crédito no existe.', 1;

    DECLARE @Ultima SMALLINT = ISNULL((SELECT MAX(NumeroCuota) FROM dbo.Cuota
                                       WHERE CreditoId = @CreditoId AND MontoPagado > 0), 0);
    DECLARE @CapitalCubierto DECIMAL(14,2) = ISNULL((SELECT SUM(Capital) FROM dbo.Cuota
                                                    WHERE CreditoId = @CreditoId AND NumeroCuota <= @Ultima), 0);
    DECLARE @Abonos DECIMAL(14,2) = ISNULL((SELECT SUM(tp.Monto) FROM dbo.TransaccionPago tp
                                            JOIN dbo.Cuota q ON q.CuotaId = tp.CuotaId
                                            WHERE q.CreditoId = @CreditoId AND tp.TipoPago = 'CAPITAL' AND tp.Anulada = 0), 0);
    DECLARE @Saldo DECIMAL(12,2) = @Monto - @CapitalCubierto - @Abonos;
    DECLARE @Restantes INT = (SELECT COUNT(*) FROM dbo.Cuota WHERE CreditoId = @CreditoId AND NumeroCuota > @Ultima);

    IF @Restantes = 0 RETURN;
    IF @Saldo <= 0
        THROW 50001, 'El saldo de capital quedaría en cero o negativo; no se pueden recalcular las cuotas.', 1;

    DECLARE @i FLOAT = CAST(@Tasa AS FLOAT) / 100.0 / 12.0;
    DECLARE @Nivelada DECIMAL(12,2) =
        ROUND(CAST(@Saldo AS FLOAT) * @i / (1.0 - POWER(1.0 + @i, -CAST(@Restantes AS FLOAT))), 2);

    DECLARE @CuotaId INT, @k INT = 0, @Interes DECIMAL(12,2), @Capital DECIMAL(12,2);
    DECLARE cq CURSOR LOCAL FAST_FORWARD FOR
        SELECT CuotaId FROM dbo.Cuota
        WHERE CreditoId = @CreditoId AND NumeroCuota > @Ultima
        ORDER BY NumeroCuota;

    BEGIN TRANSACTION;
        OPEN cq;
        FETCH NEXT FROM cq INTO @CuotaId;
        WHILE @@FETCH_STATUS = 0
        BEGIN
            SET @k += 1;
            SET @Interes = ROUND(CAST(@Saldo AS FLOAT) * @i, 2);
            SET @Capital = CASE WHEN @k = @Restantes THEN @Saldo ELSE @Nivelada - @Interes END;
            IF @Capital > @Saldo SET @Capital = @Saldo;
            IF @Capital < 0 SET @Capital = 0;

            UPDATE dbo.Cuota
               SET SaldoInicial = @Saldo, Capital = @Capital, Interes = @Interes
             WHERE CuotaId = @CuotaId;

            SET @Saldo = @Saldo - @Capital;
            FETCH NEXT FROM cq INTO @CuotaId;
        END
        CLOSE cq;
        DEALLOCATE cq;

        UPDATE cr
           SET CuotaNivelada   = @Nivelada,
               TotalIntereses  = t.Intereses,
               TotalRecaudable = t.Total + @Abonos
        FROM dbo.Credito cr
        CROSS APPLY (SELECT SUM(Interes) AS Intereses, SUM(TotalCuota) AS Total
                     FROM dbo.Cuota WHERE CreditoId = @CreditoId) t
        WHERE cr.CreditoId = @CreditoId;
    COMMIT TRANSACTION;
END
GO

-- 4. Registrar pago (con manejo del excedente) --------------------------------------
CREATE OR ALTER PROCEDURE dbo.sp_Pago_Registrar
    @CreditoId           INT,
    @NumeroCuota         SMALLINT      = NULL,
    @Monto               DECIMAL(12,2),
    @MedioPagoId         TINYINT,
    @ReferenciaBancaria  VARCHAR(40)   = NULL,
    @FechaHora           DATETIME2(0)  = NULL,
    @Excedente           VARCHAR(10)   = NULL   -- NULL, 'CUOTAS' o 'CAPITAL'
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Msg NVARCHAR(400), @EstadoCredito VARCHAR(10), @Comision DECIMAL(5,2),
            @RequiereRef BIT, @CuotaId INT, @NumCuota SMALLINT, @SaldoCuota DECIMAL(12,2),
            @Resto DECIMAL(12,2), @Aplicar DECIMAL(12,2), @Monto2 DECIMAL(12,2),
            @SaldoTotal DECIMAL(14,2), @SaldoCapital DECIMAL(14,2), @MontoFinanciado DECIMAL(12,2);
    DECLARE @Creadas TABLE (TransaccionId INT);

    SET @FechaHora = ISNULL(@FechaHora, SYSDATETIME());
    SET @ReferenciaBancaria = NULLIF(LTRIM(RTRIM(@ReferenciaBancaria)), '');
    SET @Excedente = NULLIF(UPPER(LTRIM(RTRIM(@Excedente))), '');

    SELECT @EstadoCredito = Estado, @Comision = PorcentajeComision, @MontoFinanciado = MontoFinanciado
    FROM dbo.Credito WHERE CreditoId = @CreditoId;

    IF @EstadoCredito IS NULL
        THROW 50001, 'El crédito no existe.', 1;
    IF @EstadoCredito <> 'ACTIVO'
        THROW 50001, 'Solo se pueden registrar pagos a créditos activos.', 1;
    IF @Excedente IS NOT NULL AND @Excedente NOT IN ('CUOTAS', 'CAPITAL')
        THROW 50001, 'El destino del excedente debe ser CUOTAS o CAPITAL.', 1;

    SELECT @RequiereRef = RequiereReferencia FROM dbo.MedioPago WHERE MedioPagoId = @MedioPagoId;
    IF @RequiereRef IS NULL
        THROW 50001, 'El medio de pago no existe.', 1;
    IF @RequiereRef = 1 AND @ReferenciaBancaria IS NULL
        THROW 50001, 'Este medio de pago requiere la referencia bancaria (número de autorización o de boleta).', 1;
    IF @Monto IS NULL OR @Monto <= 0
        THROW 50001, 'El monto del pago debe ser mayor a cero.', 1;

    BEGIN TRANSACTION;
        SELECT TOP (1) @CuotaId = CuotaId, @NumCuota = NumeroCuota, @SaldoCuota = TotalCuota - MontoPagado
        FROM dbo.Cuota WITH (UPDLOCK, HOLDLOCK)
        WHERE CreditoId = @CreditoId
          AND Estado <> 'PAGADA'
          AND (@NumeroCuota IS NULL OR NumeroCuota = @NumeroCuota)
        ORDER BY NumeroCuota;

        IF @CuotaId IS NULL
            THROW 50001, 'La cuota indicada no existe o ya está pagada.', 1;

        IF @Monto > @SaldoCuota AND @Excedente IS NULL
        BEGIN
            SET @Msg = CONCAT('El monto excede el saldo de la cuota ', @NumCuota,
                              ' (Q', CAST(@SaldoCuota AS VARCHAR(20)), '). Indique si el excedente de Q',
                              CAST(@Monto - @SaldoCuota AS VARCHAR(20)),
                              ' se aplica a las siguientes cuotas o se abona a capital.');
            THROW 50001, @Msg, 1;
        END

        -- Validaciones del excedente antes de grabar nada
        IF @Monto > @SaldoCuota AND @Excedente = 'CUOTAS'
        BEGIN
            SELECT @SaldoTotal = SUM(TotalCuota - MontoPagado)
            FROM dbo.Cuota WHERE CreditoId = @CreditoId AND Estado <> 'PAGADA' AND NumeroCuota >= @NumCuota;
            IF @Monto > @SaldoTotal
            BEGIN
                SET @Msg = CONCAT('El monto excede el saldo de todas las cuotas pendientes desde la cuota ', @NumCuota,
                                  ' (Q', CAST(@SaldoTotal AS VARCHAR(20)), ').');
                THROW 50001, @Msg, 1;
            END
        END

        IF @Monto > @SaldoCuota AND @Excedente = 'CAPITAL'
        BEGIN
            IF EXISTS (SELECT 1 FROM dbo.Cuota WHERE CreditoId = @CreditoId AND Estado <> 'PAGADA' AND NumeroCuota < @NumCuota)
                THROW 50001, 'Para abonar a capital el crédito debe estar al día: primero pague las cuotas anteriores.', 1;
            IF NOT EXISTS (SELECT 1 FROM dbo.Cuota WHERE CreditoId = @CreditoId AND NumeroCuota > @NumCuota)
                THROW 50001, 'Es la última cuota: no hay saldo de capital al cual abonar.', 1;
            IF EXISTS (SELECT 1 FROM dbo.Cuota WHERE CreditoId = @CreditoId AND NumeroCuota > @NumCuota AND MontoPagado > 0)
                THROW 50001, 'No se puede abonar a capital: hay cuotas posteriores con pagos registrados.', 1;

            SET @SaldoCapital = @MontoFinanciado
                - ISNULL((SELECT SUM(Capital) FROM dbo.Cuota WHERE CreditoId = @CreditoId AND NumeroCuota <= @NumCuota), 0)
                - ISNULL((SELECT SUM(tp.Monto) FROM dbo.TransaccionPago tp JOIN dbo.Cuota q ON q.CuotaId = tp.CuotaId
                          WHERE q.CreditoId = @CreditoId AND tp.TipoPago = 'CAPITAL' AND tp.Anulada = 0), 0);
            IF @Monto - @SaldoCuota >= @SaldoCapital
            BEGIN
                SET @Msg = CONCAT('El abono a capital (Q', CAST(@Monto - @SaldoCuota AS VARCHAR(20)),
                                  ') debe ser menor al saldo de capital después de esta cuota (Q',
                                  CAST(@SaldoCapital AS VARCHAR(20)), '). Para pagar todo, aplique el excedente a las siguientes cuotas.');
                THROW 50001, @Msg, 1;
            END
        END

        -- a) Pago de la cuota elegida (completo o parcial)
        SET @Aplicar = CASE WHEN @Monto < @SaldoCuota THEN @Monto ELSE @SaldoCuota END;
        SET @Resto = @Monto - @Aplicar;

        INSERT INTO dbo.TransaccionPago (CuotaId, FechaHora, Monto, MedioPagoId, ReferenciaBancaria, PorcentajeComision, TipoPago)
        OUTPUT inserted.TransaccionId INTO @Creadas
        VALUES (@CuotaId, @FechaHora, @Aplicar, @MedioPagoId, @ReferenciaBancaria, @Comision, 'CUOTA');

        UPDATE dbo.Cuota
           SET MontoPagado      = MontoPagado + @Aplicar,
               Estado           = CASE WHEN MontoPagado + @Aplicar >= TotalCuota THEN 'PAGADA' ELSE 'PARCIAL' END,
               FechaCancelacion = CASE WHEN MontoPagado + @Aplicar >= TotalCuota THEN @FechaHora ELSE NULL END
         WHERE CuotaId = @CuotaId;

        -- b) Excedente a las siguientes cuotas
        IF @Resto > 0 AND @Excedente = 'CUOTAS'
        BEGIN
            DECLARE cs CURSOR LOCAL FAST_FORWARD FOR
                SELECT CuotaId, TotalCuota - MontoPagado
                FROM dbo.Cuota
                WHERE CreditoId = @CreditoId AND Estado <> 'PAGADA' AND NumeroCuota > @NumCuota
                ORDER BY NumeroCuota;
            OPEN cs;
            FETCH NEXT FROM cs INTO @CuotaId, @SaldoCuota;
            WHILE @@FETCH_STATUS = 0 AND @Resto > 0
            BEGIN
                SET @Monto2 = CASE WHEN @Resto < @SaldoCuota THEN @Resto ELSE @SaldoCuota END;

                INSERT INTO dbo.TransaccionPago (CuotaId, FechaHora, Monto, MedioPagoId, ReferenciaBancaria, PorcentajeComision, TipoPago)
                OUTPUT inserted.TransaccionId INTO @Creadas
                VALUES (@CuotaId, @FechaHora, @Monto2, @MedioPagoId, @ReferenciaBancaria, @Comision, 'CUOTA');

                UPDATE dbo.Cuota
                   SET MontoPagado      = MontoPagado + @Monto2,
                       Estado           = CASE WHEN MontoPagado + @Monto2 >= TotalCuota THEN 'PAGADA' ELSE 'PARCIAL' END,
                       FechaCancelacion = CASE WHEN MontoPagado + @Monto2 >= TotalCuota THEN @FechaHora ELSE NULL END
                 WHERE CuotaId = @CuotaId;

                SET @Resto = @Resto - @Monto2;
                FETCH NEXT FROM cs INTO @CuotaId, @SaldoCuota;
            END
            CLOSE cs;
            DEALLOCATE cs;
        END

        -- c) Excedente como abono a capital (queda ligado a la cuota que se acaba de pagar)
        IF @Resto > 0 AND @Excedente = 'CAPITAL'
        BEGIN
            SELECT @CuotaId = CuotaId FROM dbo.Cuota WHERE CreditoId = @CreditoId AND NumeroCuota = @NumCuota;

            INSERT INTO dbo.TransaccionPago (CuotaId, FechaHora, Monto, MedioPagoId, ReferenciaBancaria, PorcentajeComision, TipoPago)
            OUTPUT inserted.TransaccionId INTO @Creadas
            VALUES (@CuotaId, @FechaHora, @Resto, @MedioPagoId, @ReferenciaBancaria, @Comision, 'CAPITAL');

            EXEC dbo.sp_Credito_RecalcularPendientes @CreditoId;
        END

        IF NOT EXISTS (SELECT 1 FROM dbo.Cuota WHERE CreditoId = @CreditoId AND Estado <> 'PAGADA')
            UPDATE dbo.Credito SET Estado = 'CANCELADO' WHERE CreditoId = @CreditoId;
    COMMIT TRANSACTION;

    SELECT tp.*
    FROM dbo.vw_TransaccionPago tp
    JOIN @Creadas c ON c.TransaccionId = tp.TransaccionId
    ORDER BY tp.TransaccionId;
END
GO

-- 5. Anular pago (también abonos a capital) ------------------------------------------
CREATE OR ALTER PROCEDURE dbo.sp_Pago_Eliminar
    @TransaccionId INT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @CuotaId INT, @Monto DECIMAL(12,2), @Anulada BIT, @Tipo VARCHAR(10),
            @CreditoId INT, @VIN CHAR(17), @EstadoCredito VARCHAR(10);

    SELECT @CuotaId = tp.CuotaId, @Monto = tp.Monto, @Anulada = tp.Anulada, @Tipo = tp.TipoPago, @CreditoId = q.CreditoId
    FROM dbo.TransaccionPago tp
    JOIN dbo.Cuota q ON q.CuotaId = tp.CuotaId
    WHERE tp.TransaccionId = @TransaccionId;

    IF @CuotaId IS NULL
        THROW 50001, 'El pago no existe.', 1;
    IF @Anulada = 1
        THROW 50001, 'El pago ya estaba anulado.', 1;

    SELECT @VIN = VIN, @EstadoCredito = Estado FROM dbo.Credito WHERE CreditoId = @CreditoId;

    IF @Tipo = 'CAPITAL'
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM dbo.Cuota q
                       WHERE q.CreditoId = @CreditoId
                         AND q.NumeroCuota > ISNULL((SELECT MAX(NumeroCuota) FROM dbo.Cuota
                                                     WHERE CreditoId = @CreditoId AND MontoPagado > 0), 0))
            THROW 50001, 'No se puede anular el abono: ya no quedan cuotas sin pagos donde reponer el saldo de capital.', 1;

        BEGIN TRANSACTION;
            UPDATE dbo.TransaccionPago SET Anulada = 1 WHERE TransaccionId = @TransaccionId;
            EXEC dbo.sp_Credito_RecalcularPendientes @CreditoId;
        COMMIT TRANSACTION;

        SELECT 'ANULADO' AS Resultado, 'Abono a capital anulado; las cuotas pendientes se recalcularon.' AS Mensaje;
        RETURN;
    END

    IF @EstadoCredito = 'CANCELADO'
       AND EXISTS (SELECT 1 FROM dbo.Credito WHERE VIN = @VIN AND Estado = 'ACTIVO' AND CreditoId <> @CreditoId)
        THROW 50001, 'No se puede anular: el vehículo ya respalda otro crédito activo.', 1;

    BEGIN TRANSACTION;
        UPDATE dbo.TransaccionPago SET Anulada = 1 WHERE TransaccionId = @TransaccionId;

        UPDATE dbo.Cuota
           SET MontoPagado      = MontoPagado - @Monto,
               Estado           = CASE WHEN MontoPagado - @Monto <= 0 THEN 'PENDIENTE' ELSE 'PARCIAL' END,
               FechaCancelacion = NULL
         WHERE CuotaId = @CuotaId;

        IF @EstadoCredito = 'CANCELADO'
            UPDATE dbo.Credito SET Estado = 'ACTIVO' WHERE CreditoId = @CreditoId;
    COMMIT TRANSACTION;

    SELECT 'ANULADO' AS Resultado, 'Pago anulado; el saldo de la cuota fue restablecido.' AS Mensaje;
END
GO

PRINT 'Pagos con excedente (cuotas siguientes o abono a capital) instalados correctamente.';
GO
